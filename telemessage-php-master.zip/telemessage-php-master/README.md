telemessage-php
===============

A PHP library for communicating with the TeleMessage REST API

Here you can find TeleMessage PHP library with examples

1. Using telemessage.phar file (tested with Windows and PHP 5.6.2)
2. Including src files as is   (tested with Windows and PHP 5.2.9, Windows and 5.6.2)
