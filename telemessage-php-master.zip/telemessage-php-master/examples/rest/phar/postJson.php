<?php
    // includes TeleMessage.
    require_once "telemessage.phar";
    // include actual example
    require_once "../postJson.php";
?>