<?php
    // includes TeleMessage.
    require_once ("../../../com/TeleMessage.class.php");
    // include actual example
    require_once "../postJson.php";
?>