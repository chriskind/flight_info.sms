This is examples of using TeleMessage REST API (http://www.telemessage.com/rest/message/status/) for sending message
and queering status.

Example is tested on:

PHP 5.2.9, Windows 7, Apache 2
PHP 5.2.4, Linux, Apache 2